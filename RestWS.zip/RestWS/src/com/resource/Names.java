package com.resource;


public class Names {

	
	private  int   projectId;
	private String projectName;
	private String description;
	private String category;
	private String highLevelDesignLink;
	private String fundamentalDocument;
	
	
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getHighLevelDesignLink() {
		return highLevelDesignLink;
	}
	public void setHighLevelDesignLink(String highLevelDesignLink) {
		this.highLevelDesignLink = highLevelDesignLink;
	}
	public String getFundamentalDocument() {
		return fundamentalDocument;
	}
	public void setFundamentalDocument(String fundamentalDocument) {
		this.fundamentalDocument = fundamentalDocument;
	}
	@Override
	public String toString() {
		return "Names [projectId=" + projectId + ", projectName=" + projectName + ", description=" + description
				+ ", category=" + category + ", highLevelDesignLink=" + highLevelDesignLink + ", fundamentalDocument="
				+ fundamentalDocument + ", getProjectId()=" + getProjectId() + ", getProjectName()=" + getProjectName()
				+ ", getDescription()=" + getDescription() + ", getCategory()=" + getCategory()
				+ ", getHighLevelDesignLink()=" + getHighLevelDesignLink() + ", getFundamentalDocument()="
				+ getFundamentalDocument() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	
	
	
	
	
	}
	
	
		
	
	
	


